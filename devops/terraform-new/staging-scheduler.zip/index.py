import boto3
import os
from datetime import datetime

def handler(event, context):
    ec2 = boto3.client('ec2')
    instance_id = os.environ['INSTANCE_ID']
    
    # Get current time in UTC
    now = datetime.utcnow()
    hour = now.hour
    
    # Business hours: 6 AM - 10 PM UTC (adjust as needed)
    # This covers most US time zones during business hours
    if 6 <= hour <= 22:
        # Start instance if stopped
        response = ec2.describe_instances(InstanceIds=[instance_id])
        state = response['Reservations'][0]['Instances'][0]['State']['Name']
        
        if state == 'stopped':
            print(f"Starting staging instance {instance_id} for business hours")
            ec2.start_instances(InstanceIds=[instance_id])
            return {'statusCode': 200, 'body': 'Instance started'}
        else:
            return {'statusCode': 200, 'body': 'Instance already running'}
    else:
        # Stop instance if running (outside business hours)
        response = ec2.describe_instances(InstanceIds=[instance_id])
        state = response['Reservations'][0]['Instances'][0]['State']['Name']
        
        if state == 'running':
            print(f"Stopping staging instance {instance_id} outside business hours")
            ec2.stop_instances(InstanceIds=[instance_id])
            return {'statusCode': 200, 'body': 'Instance stopped'}
        else:
            return {'statusCode': 200, 'body': 'Instance already stopped'}
