import boto3
import os
from datetime import datetime, timedelta

def handler(event, context):
    ec2 = boto3.client('ec2')
    cloudwatch = boto3.client('cloudwatch')
    
    instance_id = os.environ['INSTANCE_ID']
    
    # Check if instance has been idle for 30 minutes
    metrics = cloudwatch.get_metric_statistics(
        Namespace='AWS/EC2',
        MetricName='NetworkIn',
        Dimensions=[{'Name': 'InstanceId', 'Value': instance_id}],
        StartTime=datetime.utcnow() - timedelta(minutes=30),
        EndTime=datetime.utcnow(),
        Period=1800,
        Statistics=['Sum']
    )
    
    if not metrics['Datapoints'] or sum(dp['Sum'] for dp in metrics['Datapoints']) < 1048576:
        print(f"Stopping idle staging instance {instance_id}")
        ec2.stop_instances(InstanceIds=[instance_id])
        return {'statusCode': 200, 'body': 'Instance stopped'}
    
    return {'statusCode': 200, 'body': 'Instance still active'}
