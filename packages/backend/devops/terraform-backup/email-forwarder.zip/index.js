const AWS = require('aws-sdk');
const ses = new AWS.SES();

exports.handler = async (event) => {
    console.log('SES Event:', JSON.stringify(event, null, 2));
    
    for (const record of event.Records) {
        if (record.eventSource === 'aws:ses') {
            const message = record.ses.mail;
            const originalTo = message.destination[0];
            const forwardTo = process.env.FORWARD_TO_EMAIL;
            
            // Create forwarded email
            const params = {
                Source: `noreply@${process.env.FROM_DOMAIN}`,
                Destination: {
                    ToAddresses: [forwardTo]
                },
                Message: {
                    Subject: {
                        Data: `[FORWARDED from ${originalTo}] ${message.commonHeaders.subject || 'No Subject'}`
                    },
                    Body: {
                        Text: {
                            Data: `This email was forwarded from ${originalTo}\n\nOriginal sender: ${message.commonHeaders.from}\nDate: ${message.commonHeaders.date}\n\n---\n\nPlease check your S3 bucket for the full email content or set up proper email forwarding.`
                        }
                    }
                }
            };
            
            try {
                await ses.sendEmail(params).promise();
                console.log(`Email forwarded from ${originalTo} to ${forwardTo}`);
            } catch (error) {
                console.error('Error forwarding email:', error);
                throw error;
            }
        }
    }
    
    return { statusCode: 200, body: 'Emails processed successfully' };
};
