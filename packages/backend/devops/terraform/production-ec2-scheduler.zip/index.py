import boto3
import json
import os

def handler(event, context):
    if isinstance(event, str):
        try:
            event = json.loads(event)
        except json.JSONDecodeError:
            event = {}
    action = (event or {}).get("action")
    instance_id = os.environ.get("INSTANCE_ID")
    if not instance_id:
        return {"statusCode": 500, "body": "INSTANCE_ID missing"}

    ec2 = boto3.client("ec2")
    resp = ec2.describe_instances(InstanceIds=[instance_id])
    inst = resp["Reservations"][0]["Instances"][0]
    state = inst["State"]["Name"]

    if action == "start":
        if state == "running":
            return {"statusCode": 200, "body": "already running"}
        if state == "stopped":
            ec2.start_instances(InstanceIds=[instance_id])
            return {"statusCode": 200, "body": "start initiated"}
        return {"statusCode": 200, "body": f"skip start from state={state}"}

    if action == "stop":
        if state == "stopped":
            return {"statusCode": 200, "body": "already stopped"}
        if state == "running":
            ec2.stop_instances(InstanceIds=[instance_id])
            return {"statusCode": 200, "body": "stop initiated"}
        return {"statusCode": 200, "body": f"skip stop from state={state}"}

    return {"statusCode": 400, "body": f"unknown action={action}"}
